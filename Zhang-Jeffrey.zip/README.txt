Teammates are Nicholas Tee and Jeffrey Zhang, we modified mcts_modified.py 
by implementing heuristics inside rollout to direct the search towards
promising child nodes. We mainly focused on having the mcts_modified bot to go for the middle
tile whenever it was empty. by choosing the middle square it would give our bot a better chance
of winning a 3x3 tile.